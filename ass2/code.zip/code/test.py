from databasefiller import DatabaseFiller

def main():
    filler  = DatabaseFiller()

    filler.generatePlanes(5)


if __name__ == "__main__":
    main()