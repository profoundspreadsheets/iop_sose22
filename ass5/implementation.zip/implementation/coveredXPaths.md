xpath11.xp getTeamsByEmployees R2, R7
xpath12.xp getTeamsByCountries R1, R5.1, R7
xpath14.xp getSmallestTeamID
xpath23.xp getCustomerByID R2, R6
xpath31.xp getStreetsByZip R2, R6
xpath32.xp getCustomersByZip R2, R6
xpath41.xp getBarsOfPlane R3, R6
xpath42.xp getBarMinifridgeAndColor R5.3, R7

getPlanesByColor R1, R5.1, R7
getPlanesByLivery R1, R5.1, R6
getProtocolByDate R4, R7
getToiletsBetweenFlowrates R2, R5.2, R7

getCustomerOfPlane R3
getTestdateOfProtocol R3